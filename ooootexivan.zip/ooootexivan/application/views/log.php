
    <div class="login-container">
    <h2>Вход в аккаунт</h2>
    <form action="main/log" method="post"> 
        <div class="input-group">
            <label for="username">Логин:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="input-group">
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="login-btn">Войти</button>
    </form>
    <?php if (isset($error)): ?>
        <p style="color: red; margin-top: 10px;"><?php echo $error; ?></p>
    <?php endif; ?>

    <p>Нет аккаунта? <a href="main/peg">Зарегистрироваться</a></p>
</div>
