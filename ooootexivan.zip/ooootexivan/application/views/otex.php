
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <br><br>
            <h2>Отчет</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">№</th>
                        <th scope="col">Название программма</th>
                        <th scope="col">Исполнитель</th>
                        <th scope="col">Срок</th>
                        <th scope="col">Статус</th>
                    </tr>
                </thead>
                <tbody>
                <?php  
                foreach($tasks_s as $row){
                    echo '<tr>
                        <td>'.$row['id_task'].'</td>
                        <td>'.$row['title'].'</td>
                        <td>'.$row['namess'].'</td>
                        <td>'.$row['start_date'].'</td>
                        <td>'.$row['namee'].'</td>
                        <td>
                        </td>
                    </tr>';
                }
                ?>
                </tbody>
            </table>
            <br><br>
        </div>
    </div>
</div>


