<div class="container">
    <div class="row">
        <div class="col-lg-12">
<!-- Для сотрудников можно добавить похожий раздел, но с фильтром по личным заданиям -->
        <section id="employee-dashboard" style="display: none;">
            <h2>Мои задания</h2>
            <div class="task-list">
                <div class="task-card">
                    <h3>Задание 1: Разработка отчета</h3>
                    <p>Срок: 15.10.2023</p>
                    <p>Статус: <select><option>В работе</option><option>Завершено</option></select></p>
                </div>
            </div>
        </section>

        <section>
<br><br>
<table class="table">
    <thead>
        <tr>
            <th scope="col">№</th>
            <th scope="col">Название программма</th>
            <th scope="col">Срок</th>
            <th scope="col">Статус</th>
            <th scope="col">Изменение</th>
        </tr>
    </thead>
    <tbody>
<?php  
foreach($tasks_s as $row){
    echo '<tr>
        <td>'.$row['id_task'].'</td>
        <td>'.$row['title'].'</td>
        <td>'.$row['start_date'].'</td>
        <td>'.$row['namee'].'</td>  
        <td>
            <form method="post" action="cole2/upd_statusaaa" style="display:inline;">
                            <input type="hidden" name="id_task" value="'.$row['id_task'].'">
                            <input type="hidden" name="id_status" value="Завершить">  

                            <button type="submit" class="btn btn-danger">Завершить</button>
                        </form>
        </td>
    </tr>';
}
?>
</tbody>

</table>
        </section>
        </div>
    </div>
</div>


