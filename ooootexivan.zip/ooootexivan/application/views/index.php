<section>
    <div class="container">
<div class="row">
    <div class="col-lg-12">
        <br>
        <h1 style="text-align: center;">Система управления проектами для больших команд</h1>
        <br>
        
      <iframe 
        width="1350"
        height="300"
        src="https://rutube.ru/play/embed/6c1a6bb25fd1c55a0487243179b3227c"
        style="border: none;"
        allow="clipboard-write; autoplay"
        allowFullScreen>
        </iframe>
    
    </div>
</div>
</div>
</section>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <h1 style="text-align: center;">Доски</h1>
                <br>
                <div class="row row-cols-1 row-cols-md-3 g-4">
  <div class="col">
    <div class="card">
      <img src="img/seo1.png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title" style="color: blueviolet;">Стикеры</h5>
        <p class="card-text">На задачи можно прикреплять стикеры, которые выполняют различные функции: учёт времени, дедлайн и другие. Доступны системные стикеры, а также создание собственных со свободными полями.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="img/seo2.png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title" style="color: blueviolet;">Зеркальные колонки</h5>
        <p class="card-text">Можно создать колонку, которая состоит из задач других колонок. Все действия с задачами в такой колонке будут отображаться и в родительских колонках. Удобно для наблюдений за процессами и передачи задач.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="img/seo3.png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title" style="color: blueviolet;">Сводки</h5>
        <p class="card-text">На каждой доске можно создать сводки — колонки, в которые при помощи сортировки и фильтрации можно вывести задачи из всех проектов и досок по определённым критериям. Незаменимый инструмент для мониторинга процессов.</p>
      </div>
    </div>
  </div>
</div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <h1 style="text-align: center;">Таск-трекер с диаграммой Ганта</h1>
                <br>
                <div class="card-group">
  <div class="card">
    <img src="img/seo4.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" style="color: blueviolet;">Полная картина проекта</h5>
      <p class="card-text">Переключайтесь на диаграмму Ганта в 1 клик, чтобы увидеть полный график проекта. Это позволит вам легко отслеживать прогресс и своевременно вносить необходимые коррективы.</p>
    </div>

  </div>
  <div class="card">
    <img src="img/seo5.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" style="color: blueviolet;">Удобный интерфейс для простого планирования</h5>
      <p class="card-text">Интуитивно понятный интерфейс, в котором сможет разобраться каждый. Автопланирование, масштаб от дня до года, быстрое создание задач.</p>
    </div>

  </div>
  <div class="card">
    <img src="img/seo6.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" style="color: blueviolet;">Синхронизируйтесь командой</h5>
      <p class="card-text">Планируйте на диаграмме и общайтесь онлайн — чат задачи доступен по 1 клику. Совместная работа становится проще и быстрее.</p>
    </div>

  </div>
</div>
            </div>
        </div>
    </div>
</section>
<br><br>



