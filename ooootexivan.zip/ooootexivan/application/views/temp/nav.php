 <header>
<nav class="navbar bg-primary navbar-expand-lg" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="main/index">ООО РАЗГОР</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Переключатель навигации">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a  class="nav-link active" aria-current="page" href="main/index"><div class="pol1">Главная</div></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="main/log"><div class="pol4"><button  type="button" class="btn btn-outline-light">Авторизация</button></div></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
    </header>