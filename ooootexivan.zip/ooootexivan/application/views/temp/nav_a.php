 <header>
<nav class="navbar bg-primary navbar-expand-lg" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="main/index">ООО РАЗГОР</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Переключатель навигации">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a  class="nav-link active" aria-current="page" href="main/index"><div class="pol1">Главная</div></a>
        </li>
          <li class="nav-item">
          <a  class="nav-link active" aria-current="page" href="Cola/index"><div class="pol1">Создать задание</div></a>
        </li>
         <li class="nav-item">
          <a  class="nav-link active" aria-current="page" href="Cola/otex"><div class="pol1">Отчет</div></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="main/logout"><div style="margin-left: 1200px;" class="pol"><button  type="button" class="btn btn-outline-light">Выход</button></div></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
    </header>