 <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <br><br>
        <main>
        <section>
            <h2>Создать новое задание</h2>
<form method="post" action="cola/index">
  <div class="mb-3">
    <label for="title" class="form-label">Название программа:</label>
    <input type="text" name="title" class="form-control" id="title" required>
  </div>
  <div class="mb-3">
    <label for="namess" class="form-label">Исполнитель:</label>
    <input type="text" name="namess" class="form-control" id="namess" required>
  </div>
  <div class="mb-3">
    <label for="start_date" class="form-label">Срок:</label>
    <input type="date" name="start_date" class="form-control" id="start_date" required>
  </div>
  <div class="mb-3">
    
    <label for="delivery_method" class="form-label">Выбрать ожидание</label>
    <select class="form-select" name="id_status" aria-label="Default select example">
      <?php
      foreach ($task_statuses as $row) {
          echo '<option value="' . $row['id_status'] . '">' . $row['namee'] . '</option>';
      }
      ?>
    </select>
  </div>
  <button type="submit" class="btn btn-primary">Отправить</button>
</form>
<br><br>
<table class="table">
    <thead>
        <tr>
            <th scope="col">№</th>
            <th scope="col">Название программма</th>
            <th scope="col">Исполнитель</th>
            <th scope="col">Срок</th>
            <th scope="col">Статус</th>
            <th scope="col">Изменение</th>
        </tr>
    </thead>
    <tbody>
<?php  
foreach($tasks_s as $row){
    echo '<tr>
        <td>'.$row['id_task'].'</td>
        <td>'.$row['title'].'</td>
        <td>'.$row['namess'].'</td>
        <td>'.$row['start_date'].'</td>
        <td>'.$row['namee'].'</td>  
        <td>
            <form action="cola/upd_status" method="post"> 
                <select name="id_status">';    
                foreach($task_statuses as $status) {
                    $selected = ($status['id_status'] == $row['id_status']) ? 'selected' : '';  
                    echo '<option value="'.$status['id_status'].'" '.$selected.'>'.$status['namee'].'</option>';
                }
                echo '</select>
                <input type="hidden" value="'.$row['id_task'].'" name="id_task"> 
                <button type="submit" class="btn btn-danger">Сохранить</button>
            </form>
        </td>
    </tr>';
}
?>
</tbody>

</table>
        </section>
        
        
    </main>


        </div>
    </div>
 </div>
 
 