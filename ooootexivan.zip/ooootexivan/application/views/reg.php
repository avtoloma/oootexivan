 <div class="register-container">
        <h2>Создать аккаунт</h2>
        <form action="main/peg" method="post"> 
            <div class="input-group">
                <label for="name">Имя:</label>
                <input type="name" id="name" name="name" required>
            </div>
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="password">Пароль:</label>
                <input type="password" id="password" name="password" required minlength="6">
            </div>
            <button type="submit" class="register-btn">Зарегистрироваться</button>
        </form>
        <p>Уже есть аккаунт? <a href="main/log">Войти</a></p>
    </div>