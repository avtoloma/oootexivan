<?php 
 class Col_model extends CI_Model {
    public function cola_t() {
    $sql = "SELECT * FROM `tasks` join task_statuses on tasks.id_status = task_statuses.id_status";
    $result = $this->db->query($sql);
    return $result->result_array();
    }

       public function pol_updataa($id_task, $id_status) {
    $sql = "UPDATE `tasks` SET `id_status` = ? WHERE id_task = ?";
    $result = $this->db->query($sql, array($id_status, $id_task));  
    return $result;
}

public function get_status_id_by_name($nameee) {
    $sql = "SELECT id_status FROM task_statuses WHERE namee = ?";  // Предполагаю, что поле с именем — 'name'. Если оно называется иначе (например, 'namee'), замени.
    $query = $this->db->query($sql, array($nameee));
    $result = $query->row();
    return $result ? $result->id_status : null;  // Возвращает ID или null, если статуса нет.
}

    
}
?>