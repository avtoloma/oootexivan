<?php 
 class Users_models extends CI_Model {
 public function reg_insert($name, $email, $password) {
        $sql = "INSERT INTO `users`(`name`, `email`, `password`) VALUES (?,?,?)";
        $result = $this->db->query($sql , array($name, $email, $password));
        return $result;
    }

    public function autch_select($name, $password) {
        $sql = "SELECT * FROM `users` WHERE name = ? AND password = ?";
        $result = $this->db->query($sql, array($name, $password));
        return $result->row_array();
    }
}
?>