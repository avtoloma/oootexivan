<?php 
 class Pol_model extends CI_Model {
 public function pol_insert($title, $namess, $start_date, $id_status) {
        $sql = "INSERT INTO `tasks` (`title`, `namess`, `start_date`, `id_status`) 
        VALUES (?, ?, ?, ?)";
        $result = $this->db->query($sql, array($title, $namess, $start_date, 
        $id_status));
        return $result;
    }
public function pol2($id_status, $namee , $task_statuses) {
        $sql = $this->db->query("SELECT id_status, namee FROM task_statuses");
        $result = $this->db->query($sql , array($id_status, $namee , $task_statuses));
        $result->result_array();
    }

    public function tasks_s() {
    $sql = "SELECT tasks.id_task, tasks.title, tasks.namess, tasks.start_date, task_statuses.namee FROM tasks, task_statuses WHERE tasks.id_status = task_statuses.id_status";
    $result = $this->db->query($sql);
    return $result->result_array();
    }

     public function tasks_sa() {
    $sql = "SELECT * FROM `task_statuses`";
    $result = $this->db->query($sql);
    return $result->result_array();
    }

   public function pol_updata($id_task, $id_status) {
    $sql = "UPDATE `tasks` SET `id_status` = ? WHERE id_task = ?";
    $result = $this->db->query($sql, array($id_status, $id_task));  
    return $result;
}
}
?>