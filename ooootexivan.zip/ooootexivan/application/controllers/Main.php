<?php 
class Main extends CI_Controller {
    public function index() {
        if ($this->session->userdata('role')) {
        $role = $this->session->userdata('role');
        if ($role == 'сотрудниками') {
            $this->load->view('temp/nav_b.php');
        } elseif ($role == 'руководителями') {
            $this->load->view('temp/nav_a.php');
        } else {
            $this->load->view('temp/nav.php');
        }
    } else {
        $this->load->view('temp/nav.php');
    }
        $this->load->view('temp/head.php');
        $this->load->view('index.php');
        $this->load->view('temp/footer.php');
    }

public function log() {
    $data = []; 

    if (!empty($_POST)) {
        $name = $_POST['name'];
        $password = $_POST['password'];
        $this->load->model('Users_models');
        $user = $this->Users_models->autch_select($name, $password);

        if ($user) {
            $this->session->set_userdata('role', $user['role']);
            redirect('main/index');
            return; 
        } else {
            $data['error'] = "Неверный логин или пароль"; 
        }
    }
    $this->load->view('temp/head2.php', $data);
    $this->load->view('log.php', $data);
}

    public function peg() {
         if (!empty($_POST)) {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $this->load->model('Users_models');
            $this->Users_models->reg_insert($name, $email, $password);
        }
        $this->load->view('temp/head3.php');
        $this->load->view('reg.php');
        
    }

    public function logout() {
        $this->session->unset_userdata('role');
        redirect('main/index');
    }
}
?>