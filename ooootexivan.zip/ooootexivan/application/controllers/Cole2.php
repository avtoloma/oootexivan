<?php 

class Cole2 extends CI_Controller {
    
    public function selecta_ocd() {
        $this->load->view('temp/head.php');
        $this->load->view('temp/nav_b.php');
         $this->load->model('Col_model'); 
        $data['tasks_s'] = $this->Col_model->cola_t();
        $this->load->view('cot.php', $data);
        $this->load->view('temp/footer.php');
    }
    public function upd_statusaaa() {
        if (!empty($_POST)) {
            $id_task = $_POST['id_task'];
            $id_status_name = $_POST['id_status']; 
            
            $this->load->model('Col_model');
            $id_status = $this->Col_model->get_status_id_by_name($id_status_name);
            
            if ($id_status !== null) {
                $this->Col_model->pol_updataa($id_task, $id_status);
                redirect('cole2/selecta_ocd');  
            } else {
                echo "Ошибка: статус '$id_status_name' не найден в базе.";
                redirect('cole2/selecta_ocd');  
            }
        }
    }
}
?>
