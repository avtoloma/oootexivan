<?php 
class Cola extends CI_Controller {
    public function index() {

        if (!empty($_POST)) {
           $title = $_POST['title'];
           $namess = $_POST['namess'];
           $start_date = $_POST['start_date'];
           $id_status = $_POST['id_status'];
           $this->load->model('Pol_model');
           $this->Pol_model->pol_insert($title, $namess, 
           $start_date, $id_status);
        }

        $this->load->view('temp/head.php');
        $this->load->view('temp/nav_a.php');
        $this->load->model('Pol_model'); 
        $data['tasks_s'] = $this->Pol_model->tasks_s(); 
        $data['task_statuses'] = $this->Pol_model->tasks_sa(); 
        $this->load->view('poi.php', $data);
        $this->load->view('temp/footer.php');
    }

    public function upd_status(){
    if (!empty($_POST)) {
        $id_task = $_POST['id_task'];
        $id_status = $_POST['id_status'];
        // Добавь проверку: убедись, что id_status существует в task_statuses
        $this->load->model('Pol_model');
        // Например, проверь через запрос или массив
          // Добавь этот метод в модель, если нужно
            $this->Pol_model->pol_updata($id_task, $id_status);
            redirect('cola/index');
    }
}



    public function otex() {
         $this->load->view('temp/head.php');
        $this->load->view('temp/nav_a.php');
        $this->load->model('Pol_model'); 
        $data['tasks_s'] = $this->Pol_model->tasks_s(); 
        $this->load->view('otex.php', $data);
        $this->load->view('temp/footer.php');
    }
}
?>